#include <iostream>
#include <string>
using namespace std;
#include "Book.hpp"
#include "Library.hpp"

void Phase1_Test1()
{
	Book book1;
	book1.SetBookInfo("To Kill a Mockingbird" , "Harper Lee");
	book1.GetTitle();
	book1.GetAuthor();
	
	Book book2;
	book2.SetPurchaseStatus(OWNED);
	book2.GetPurchaseStatus();
	book2.GetPurchaseStatusString();

	Book book3;
	book3.SetReadingStatus(READING);
	book3.GetReadingStatus();
	book3.GetReadingStatusString();

	Book book4;
	book4.SetBookInfo("Of Mice and Men", "John Steinback");
	book4.SetReadingStatus(NOT_STARTED);
	book4.SetPurchaseStatus(WISHLIST);
	book4.DisplayBook();

}


int main()
{
	Phase1_Test1();

	cin.get();
	cin.ignore();
	return 0;
}