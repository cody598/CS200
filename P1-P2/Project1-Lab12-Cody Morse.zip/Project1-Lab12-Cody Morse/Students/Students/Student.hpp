#ifndef _STUDENT_HPP
#define _STUDENT_HPP

#include <string>
using namespace std;

// Object declaration
struct Student
{
	string name;
	string degree;
	double gpa;
};

#endif
